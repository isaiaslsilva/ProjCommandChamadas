package br.com.main;

import br.com.modelo.Ura;
import br.com.modelo.Vendas;
import br.com.modelo.Faturas;

public class MainChamadas {

	public static void main(String[] args) {
		Ura fila = new Ura();
		fila.adicionarEquipe(new Vendas("Chamada Vendas"));
		fila.adicionarEquipe(new Faturas("Chamada Faturas"));

		
		fila.Direcionachamada();
		
	}
	
	
	
}
