package br.com.modelo;

import br.com.generico.Equipe;

public class Vendas implements Equipe {

	private String texto;
	
	public Vendas(String texto) {
		super();
		this.texto = texto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	@Override
	public void Direcionachamada() {
		System.out.println("Equipe Vendas: " + getTexto());
	}
	
}
