package br.com.modelo;

import java.util.ArrayList;
import java.util.List;

import br.com.generico.Equipe;

public class Ura {	
	private List<Equipe> listaEquipe;
	public Ura() {
		super();
		this.listaEquipe = new ArrayList<Equipe>();
	}
	public List<Equipe> getlistaEquipe() {
		return listaEquipe;
	}
	public void setlistaEquipe(List<Equipe> listaEquipe) {
		this.listaEquipe = listaEquipe;
	}
	public void adicionarEquipe(Equipe equipe) {
		getlistaEquipe().add(equipe);
	}	
	public void Direcionachamada() {
		for (Equipe equipe : getlistaEquipe()) {
			equipe.Direcionachamada();
		}
	}


}
