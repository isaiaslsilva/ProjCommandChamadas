package br.com.generico;

public interface Equipe {
	
	public void Direcionachamada();

}
